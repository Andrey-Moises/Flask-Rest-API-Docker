
import os
from   db              import db
import models
from   flask           import Flask
from   flask_smorest   import Api
from   resources.items import blp as items_blp
from   resources.store import blp as store_blp
from   resources.tag   import blp as tag_blp

def create_app(db_url=None):
    app = Flask(__name__)

    app.config["PROPAGATE_EXCEPTIONS"]           = True
    app.config["API_TITLE"]                      = "Store REST API"
    app.config["API_VERSION"]                    = "1.0"
    app.config["OPENAPI_VERSION"]                = "3.0.3"
    app.config["OPENAPI_URL_PREFIX"]             = "/"
    app.config["OPENAPI_SWAGGER_UI_PATH"]        = "/"
    app.config["OPENAPI_SWAGGER_UI_URL"]         = "https://cdn.jsdelivr.net/npm/swagger-ui-dist/"
    app.config["SQLALCHEMY_DATABASE_URI"]        = db_url or os.environ.get("DATABASE_URL", "sqlite:///data.db")
    app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False
    db.init_app(app)

    api = Api(app)

    with app.app_context():
        db.create_all()

    api.register_blueprint(items_blp)
    api.register_blueprint(store_blp)
    api.register_blueprint(tag_blp)

    return app

